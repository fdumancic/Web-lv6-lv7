var mongoose = require('mongoose');  
var blobSchema = new mongoose.Schema({  
  name: String,
  description: String,
  price: Number,
  finished: String,
  start: { type: Date, default: Date.now },
  end: { type: Date, default: Date.now }
});
mongoose.model('Blob', blobSchema);